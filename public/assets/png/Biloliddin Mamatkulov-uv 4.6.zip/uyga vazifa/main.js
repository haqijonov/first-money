document.body.innerHTML = `
  <button id="start">O'yinni Boshlash</button>
  <button id="end">O'yinni Tugatish</button>
  <div id="result"></div>
`;

let score = 0;
let randomNumber;
let isGameActive = false;

function generateRandomNumber() {
  return Math.floor(Math.random() * 10) + 1;
}

function updateResult(message) {
  document.getElementById('result').innerText = message;
}

document.getElementById('start').addEventListener('click', function () {
  if (!isGameActive) {
    randomNumber = generateRandomNumber();
    isGameActive = true;
    updateResult("O'yin boshlandi! Sonni topishga harakat qiling.");
  }

  const userInput = parseInt(prompt("1 dan 10 gacha son kiriting:"), 10);

  if (!isNaN(userInput)) {
    if (userInput === randomNumber) {
      score += 10;
      updateResult(`To'g'ri topdingiz! Ballaringiz: ${score}`);
    } else if (Math.abs(userInput - randomNumber) === 1) {
      score += 2;
      updateResult(`Yaqin! Ballaringiz: ${score}`);
    } else {
      score = 0;
      updateResult(`Noto'g'ri. Ballaringiz 0 ga tenglashtirildi.`);
    }
  } else {
    updateResult("Faqat son kiriting!");
  }
});

document.getElementById('end').addEventListener('click', function () {
  if (isGameActive) {
    isGameActive = false;
    updateResult(`O'yin tugadi. Yakuniy ballaringiz: ${score}`);
    score = 0;
  } else {
    updateResult("O'yin allaqachon tugatilgan.");
  }
});
